import os

def demo_reply():
    token = os.getenv("AI_API_KEY")
    return "Demo only" if token else "missing configuration"
